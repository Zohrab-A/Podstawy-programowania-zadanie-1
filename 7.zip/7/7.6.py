speed = int(input("Enter the speed in km/h: "))
valid = speed>=40 | speed<=140
print(f'Car speed is valid {valid}')