import math

#program do obliczania diagonalnej
a = 5
b = 8

diagonal = math.sqrt(a**2 + b**2)

print("dlugosc diagonalnej to:", diagonal)



