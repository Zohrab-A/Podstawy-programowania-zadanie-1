# A program for swapping two variable values
#
x=7
y =34
z=0
print("Przed zamiana: x =", x, "y =", y)

z=x
x = y
y = z

print("Po zamianie: x =", x, "y =", y)
