import math
# program do obliczania odleglosci horyzontu
h=float(input("Podaj wysokosc obserwatora w metrach: "))

d=math.sqrt(h)*3.57

print("Odległość horyzontu to : ", d)




