#program do przeliczania kmh na ms
kmh=float(input('Wpisz predkosc w km/h: '))

ms=kmh * 0.277777778

print('Predkosc w metrach na sekunde to: ',ms)


