###
# A program that prints your height both in cm and in feet and inches.
#
cm=float(input("Podaj swój wzrost w cm :"))
feet =cm/30.48
inches = cm/2.54
# calculate the number of feet

print(f'I am {cm}cm tall and its {feet} feet or {inches} in inches')