###
# A program that reads temperature in degrees Celsius from the keyboard.
# Use comments to briefly describe the program's algorithm.
#

# wprowadzenie stopni celcjusza
c=float(input("Podaj wartość w stopniach C : "))
# Przeliczenie na fahrenheity
f = (c * 9 / 5) + 32
# przeliczenie na kelviny
k=c+273.15
print(f'Jest {c} stopni celcjusza')
print(f'Jest {f} fahrenheitow')
print(f'Jest {k} kelwinow')