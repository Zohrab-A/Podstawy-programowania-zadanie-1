#program zamieniajacy liczby dziesietne na binarne i szesnastkowe

numer = int(input("Wpisz numer: "))

# Konwersja numerow na binarny i szesnastkowy
numer_binarny = bin(numer)
numer_szesnastkowy = hex(numer)

# wyniki
print(f"Numer binarny : {numer_binarny}")
print(f"Numer szesnastkowy: {numer_szesnastkowy}")
