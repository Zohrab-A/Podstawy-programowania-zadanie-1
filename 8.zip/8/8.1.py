###
# Calculation of circle area and circumference
#
r=float(input("Podaj długość promienia: "))
pi=3.14
# determine radius and PI values
# calculate area
p=pi*r*r
# calculate circumference
obw=pi*r*2
# print results
print(f'Obwod okregu to :{obw}')
print(f'Pole okregu to :{p}')