###
# A program that reads a SWIFT code from the keyboard
# and prints the bank code and country code.
#
swift = input('Wprowadź SWIFT code')
#pierwsze 4 litery
kod_banku = swift[:4]
#nastepne 2
kod_kraju = swift[4:6]
#drukowanie wyniku
print(f'Bank Code: {kod_banku}')
print(f'Country Code: {kod_kraju}')